package com.example.dialogdemo.module

import com.tencent.kuikly.core.render.android.export.KuiklyRenderBaseModule

class KRShareModule : KuiklyRenderBaseModule() {
    companion object {
        const val MODULE_NAME = "HRShareModule"

    }
}