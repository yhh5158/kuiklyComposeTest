package com.example.dialogdemo

import kotlin.math.ceil

object MeasureUtils {

    fun measureTextLines(text: String, fontSize: Float, width: Float, maxLines: Int, fontWeight: Int = 400): Int {
        if (text.isEmpty()) return 0
        if (width <= 0f) return maxLines
        fun isCjkOrFullWidth(c: Char): Boolean {
            val code = c.code
            return code in 0x4E00..0x9FFF ||
                    code in 0x3400..0x4DBF ||
                    code in 0xF900..0xFAFF ||
                    code in 0x3000..0x303F ||
                    code in 0xFF00..0xFFEF
        }
        fun unitForChar(c: Char): Float {
            val base = when {
                c == ' ' -> 0.33f
                c == '\n' -> 0f
                isCjkOrFullWidth(c) -> 1f
                c.isDigit() -> 0.55f
                c.isLetter() -> 0.6f
                else -> 0.5f
            }
            // Simple weight compensation
            return if (fontWeight >= 600) base * 1.15f
            else if (fontWeight >= 500) base * 1.08f
            else base
        }
        fun segmentLines(segment: String): Int {
            if (segment.isEmpty()) return 1
            var units = 0f
            for (ch in segment) {
                units += unitForChar(ch)
            }
            val estWidth = units * fontSize
            val lines = ceil(estWidth / width).toInt()
            return lines.coerceAtLeast(1)
        }
        var total = 0
        val parts = text.split('\n')
        for (part in parts) {
            total += segmentLines(part)
            if (total >= maxLines) return maxLines
        }
        return total
    }
}