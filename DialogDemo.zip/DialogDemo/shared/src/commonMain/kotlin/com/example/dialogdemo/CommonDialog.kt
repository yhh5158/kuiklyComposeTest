/*
 * Copyright (C) 2024 Foundersc. All rights reserved.
 */

package com.example.dialogdemo

import com.tencent.kuikly.core.base.Animation
import com.tencent.kuikly.core.base.Color
import com.tencent.kuikly.core.base.ComposeAttr
import com.tencent.kuikly.core.base.ComposeEvent
import com.tencent.kuikly.core.base.ComposeView
import com.tencent.kuikly.core.base.Rotate
import com.tencent.kuikly.core.base.ViewBuilder
import com.tencent.kuikly.core.base.ViewContainer
import com.tencent.kuikly.core.base.attr.ImageUri
import com.tencent.kuikly.core.base.event.didAppear
import com.tencent.kuikly.core.directives.vbind
import com.tencent.kuikly.core.directives.vif
import com.tencent.kuikly.core.layout.FlexAlign
import com.tencent.kuikly.core.reactive.handler.observable
import com.tencent.kuikly.core.timer.setTimeout
import com.tencent.kuikly.core.views.Canvas
import com.tencent.kuikly.core.views.Image
import com.tencent.kuikly.core.views.Modal
import com.tencent.kuikly.core.views.Scroller
import com.tencent.kuikly.core.views.Text
import com.tencent.kuikly.core.views.TextAttr
import com.tencent.kuikly.core.views.TransitionType
import com.tencent.kuikly.core.views.TransitionView
import com.tencent.kuikly.core.views.View
import com.tencent.kuikly.core.views.compose.Button
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * A generic dialog component complying with strict design guidelines:
 * - 1-3 buttons with primary/secondary styles.
 * - Content: Text or Key-Value pairs.
 * - Height: Min 160px, Max (Screen - TopBar).
 * - Safe area handling.
 */

internal fun ViewContainer<*, *>.CommonDialog(init: CommonDialog.() -> Unit) {
    addChild(CommonDialog(), init)
}

open class CommonDialogAttr : ComposeAttr() {

    enum class ContentType {
        TEXT,
        KV_LIST,
        CUSTOM
    }

    enum class LayoutType {
        BOTTOM_SHEET,
        CENTER_MODAL
    }

    internal var showDialog by observable(false)
    internal var layoutType = LayoutType.BOTTOM_SHEET
    internal var icon = ""
    internal var title = ""
    internal var titleAttrInit: (TextAttr.() -> Unit)? = null
    internal var description = ""
    internal var descriptionAttrInit: (TextAttr.() -> Unit)? = null

    // Content
    /*
     * 由于Scroller无法使用flex(1)撑起高度，copy了一份content内容当做Ghost View用于撑起高度，但数据监听会触发两次。
     * 增加useScroller开关，需要滑动时再使用Scroller，优化性能。
     */
    internal var useScroller = false
    internal var contentType = ContentType.TEXT
    internal var contentText = ""
    internal var contentKvList = ArrayList<Pair<String, String>>()
    internal var customContentBuilder: ViewBuilder? = null
    // Buttons
    internal var buttons: ArrayList<CommonDialogButtonModel> by observable(ArrayList())
    internal var needPrimaryLoading = false
    fun showDialog(isShow: Boolean) {
        this.showDialog = isShow
    }

    fun layoutType(type: LayoutType) {
        this.layoutType = type
    }
    /**
     * 自定义内容构建器
     */
//    fun customContentBuilder(builder: ViewBuilder) {
//        this.customContentBuilder = builder
//    }

    fun icon(icon: String) {
        this.icon = icon
    }

    fun title(title: String) {
        this.title = title
    }

    fun titleAttr(init: TextAttr.() -> Unit) {
        this.titleAttrInit = init
    }

    fun description(description: String) {
        this.description = description
    }

    fun descriptionAttr(init: TextAttr.() -> Unit) {
        this.descriptionAttrInit = init
    }

//    fun contentType(contentType: CommonDialogAttr.ContentType) {
//        this.contentType = contentType
//    }

    fun useScroller(use: Boolean) {
        this.useScroller = use
    }

    fun content(text: String) {
        this.contentType = ContentType.TEXT
        this.contentText = text
    }

    fun content(kvList: ArrayList<Pair<String, String>>) {
        this.contentType = ContentType.KV_LIST
        this.contentKvList = kvList
    }

    fun content(builder: ViewBuilder) {
        this.contentType = ContentType.CUSTOM
        this.customContentBuilder = builder
    }

    fun buttons(btns: ArrayList<CommonDialogButtonModel>) {
        this.buttons = btns
    }

    fun needPrimaryLoading(need: Boolean) {
        this.needPrimaryLoading = need
    }
}

class CommonDialogEvent : ComposeEvent() {
        var onButtonClick: ((Int) -> Unit)? = null
        var onCancel: (() -> Unit)? = null
}

class CommonDialog : ComposeView<CommonDialogAttr, CommonDialogEvent>() {

    private var showDialog by observable(false)

    private var showPrimaryLoading by observable(false)
    private var primaryLoadingAnimating by observable(false)

    override fun createAttr() = CommonDialogAttr()
    override fun createEvent() = CommonDialogEvent()

    override fun didInit() {
        super.didInit()
        showDialog = attr.showDialog
    }


    override fun body(): ViewBuilder {
        val ctx = this

        return {

            vif({ ctx.attr.showDialog || ctx.showDialog }) {
                // 获取安全区域
                ctx.showPrimaryLoading = false
                ctx.primaryLoadingAnimating = false

                val safeArea = ctx.pagerData.safeAreaInsets
                // 获取屏幕高度
                val windowHeight = ctx.pagerData.pageViewHeight
                // Logic: Distance from safe area top 10px -> safeBottom + 10. If no safe area (safeBottom=0), use 20.
                val bottomMargin = if (safeArea.bottom > 0) safeArea.bottom + 10f else 20f

                val navBarHeight = safeArea.top
                val statusBar = ctx.pagerData.statusBarHeight

                // Layout Config based on Type
                val isCenter = ctx.attr.layoutType == CommonDialogAttr.LayoutType.CENTER_MODAL

                // Height Constraints
                val maxHeight = if (isCenter) {
                    windowHeight * 0.7f
                } else {
                    windowHeight - statusBar - navBarHeight
                }
                val minHeight = if (isCenter) 160f else 0f

                // Width & Layout Params
                val containerWidth = if (isCenter) 295f else ctx.pagerData.pageViewWidth
                val containerRadius = 24f
                val containerLeftRightPadding = 20f
                val containerBottomRadius = if (isCenter) 24f else 0f
                val containerBottomPadding = if (isCenter) 20f else bottomMargin
                Modal(true) {
                    attr {
                        if (isCenter) {
                            justifyContentCenter()
                            alignItemsCenter()
                        } else {
                            justifyContentFlexEnd() // Align to bottom
                        }
                    }

                    // Overlay with Fade Transition
                    TransitionView(type = TransitionType.FADE_IN_OUT) {
                        attr {
                            transitionAppear(ctx.attr.showDialog)
                            absolutePositionAllZero()
                            customAnimation(Animation.springEaseInOut(0.3f, 0.9f, 1f))
                            backgroundColor(Color(0x59000000)) // rgba(0,0,0,0.35) = 35% opacity
                        }
                        event {
                            click {
                                if (!isCenter) {
                                    ctx.event.onCancel?.invoke()
                                }
                            }
                        }
                    }


                    // Dialog Container with Slide Transition
                    TransitionView(type = if (isCenter) TransitionType.FADE_IN_OUT else TransitionType.DIRECTION_FROM_BOTTOM) {
                        attr {
                            transitionAppear(ctx.attr.showDialog)
                            customAnimation(Animation.springEaseInOut(0.3f, 0.9f, 1f))
                        }
                        event {
                            transitionFinish { appear ->
                                ctx.showDialog = appear
                                if (!(ctx.attr.showDialog || ctx.attr.showDialog)) {
                                    ctx.event.onCancel?.invoke()
                                }
                            }
                        }

                        View {
                            attr {
                                debugName("containView")
                                width(containerWidth)
                                maxHeight(maxHeight)
                                minHeight(minHeight)
                                backgroundColor(0xFFF5F6FA)
                                borderRadius(containerRadius, containerRadius, containerBottomRadius, containerBottomRadius)
                                paddingTop(24f)
                                paddingLeft(containerLeftRightPadding)
                                paddingRight(containerLeftRightPadding)
                                paddingBottom(containerBottomPadding)

                                alignItems(FlexAlign.STRETCH)
                                flexDirectionColumn()
                            }
                            event {
                                click {  }
                            }

                            // Title
                            if (ctx.attr.title.isNotEmpty()) {
                                View {
                                    attr {
                                        flexDirectionRow()
                                        flex(1f)
                                        alignItems(FlexAlign.FLEX_START)
                                        marginBottom(16f)
                                    }
                                    if (ctx.attr.icon.isNotEmpty()) {
                                        Image {
                                            attr {
                                                src(ImageUri.commonAssets(ctx.attr.icon))
                                                size(24f, 24f)
                                                marginRight(8f)
                                                marginTop(2f) // (28 - 24) / 2 to align with text baseline
                                            }
                                        }
                                    }
                                    Text {
                                        attr {
                                            text(ctx.attr.title)
                                            fontSize(20f)
                                            fontWeightMedium()
                                            textAlignLeft()
                                            lineHeight(28f)
                                            lines(2)
                                            textOverFlowTail()
                                            color(Color.BLACK)
                                            flex(1f)

                                            // 应用外部自定义样式
                                            ctx.attr.titleAttrInit?.invoke(this)
                                        }
                                    }
                                }
                            }

                            // Description
                            if (ctx.attr.description.isNotEmpty()) {
                                Text {
                                    attr {
                                        text(ctx.attr.description)
                                        fontSize(16f)
                                        fontWeightNormal()
                                        textAlignLeft()
                                        lineHeight(24f)
                                        lines(2)
                                        textOverFlowTail()
                                        color(Color.RED)
                                        marginBottom(12f)

                                        // 应用外部自定义样式
                                        ctx.attr.descriptionAttrInit?.invoke(this)
                                    }
                                }
                            }

                            // Scrollable Content
                            // Calculate occupied height to constrain scroller
                            val availableWidth = containerWidth - (containerLeftRightPadding * 2)
                            val titleAvailableWidth = if (ctx.attr.icon.isNotEmpty()) availableWidth - 32f else availableWidth


                            val titleLines = if (ctx.attr.title.isNotEmpty()) MeasureUtils.measureTextLines(ctx.attr.title, 20f, titleAvailableWidth, 2, 500) else 0
                            val titleTotalHeight = if (ctx.attr.title.isNotEmpty()) titleLines * 28f + 16f else 0f
                            val descLines = if (ctx.attr.description.isNotEmpty()) MeasureUtils.measureTextLines(ctx.attr.description, 16f, availableWidth, 2) else 0
                            val descTotalHeight = if (ctx.attr.title.isNotEmpty()) descLines * 24f + 12f else 0f

                            val buttonTotalHeight = if (ctx.attr.buttons.isNotEmpty()) {
                                if (ctx.attr.buttons.size == 3) 156f else 44f // Vertical: 3*44 + 2*12. Horizontal: 44.
                            } else 0f

                            // Top padding (24) + Scroller margin bottom (16)
                            val layoutVerticalPadding = 24f + 16f
                            val maxScrollerHeight = maxHeight - titleTotalHeight - descTotalHeight - buttonTotalHeight - layoutVerticalPadding - containerBottomPadding

                            val renderContent: ViewBuilder = {
                                View {
                                    attr {
                                        flexDirectionColumn()
                                        paddingBottom(16f) // Add bottom padding to content
                                    }
                                    if (ctx.attr.contentType == CommonDialogAttr.ContentType.TEXT) {
                                        Text {
                                            attr {
                                                text(ctx.attr.contentText)
                                                fontSize(16f)
                                                color(Color(0xFF000000))
                                                textAlignLeft()
                                                lineHeight(24f)
                                            }
                                        }
                                    } else if (ctx.attr.contentType == CommonDialogAttr.ContentType.KV_LIST) {
                                        ctx.attr.contentKvList.forEachIndexed { index, kv ->
                                            View {
                                                attr {
                                                    flexDirectionRow()
                                                    justifyContentSpaceBetween()
                                                    marginBottom(if (index == ctx.attr.contentKvList.size - 1) 0f else 12f)
                                                    alignItems(FlexAlign.FLEX_START)
                                                }
                                                Text {
                                                    attr {
                                                        text(kv.first)
                                                        fontSize(16f)
                                                        fontWeightNormal()
                                                        lineHeight(22f)
                                                        color(Color(0xff7E828F))
                                                        marginRight(12f)
                                                    }
                                                }
                                                Text {
                                                    attr {
                                                        text(kv.second)
                                                        fontSize(16f)
                                                        fontWeightNormal()
                                                        lineHeight(22f)
                                                        color(Color(0xff000000))
                                                        flex(1f)
                                                        textAlignRight()
                                                    }
                                                }
                                            }
                                        }
                                    } else if (ctx.attr.contentType == CommonDialogAttr.ContentType.CUSTOM) {
                                        ctx.attr.customContentBuilder?.invoke(this)
                                    }
                                }
                            }

                            View {
                                attr {
                                    debugName("contentContainView")
                                    maxHeight(if (maxScrollerHeight > 0) maxScrollerHeight else 0f)
                                    marginBottom(16f) // Reduce margin to 16f
                                }
                                // 1. Ghost View (Invisible, props the height)
                                View {
                                    attr {
                                        debugName("GhostView")
                                        opacity(if (ctx.attr.useScroller) 0f else 1f)
                                    }
                                    renderContent()
                                }
                                // 2. Real Scroller (Absolute, fills the wrapper)
                                if (ctx.attr.useScroller) {
                                    Scroller {
                                        attr {
                                            debugName("contentScroller")
                                            positionAbsolute()
                                            top(0f); left(0f); right(0f); bottom(0f)
                                            setContentInset(0f, 0f, 0f, 0f)
                                            bouncesEnable(false)

                                        }
                                        renderContent()
                                    }
                                }
                            }

                            // Buttons
                            if (ctx.attr.buttons.isNotEmpty()) {
                                val isVertical = ctx.attr.buttons.size == 3

                                View {
                                    attr {
                                        debugName("buttonsView")
                                        if (isVertical) {
                                            flexDirectionColumn()
                                        } else {
                                            flexDirectionRow()
                                            justifyContentSpaceBetween()
                                        }
                                    }

                                    vbind({ ctx.showPrimaryLoading }) {
                                    ctx.attr.buttons.forEachIndexed { index, btn ->
                                        if (index > 0) {
                                            View {
                                                attr {
                                                    size(10f, 12f)
                                                }
                                            }
                                        }
                                        if (ctx.showPrimaryLoading && btn.style == CommonDialogButtonModel.ButtonStyle.PRIMARY) {
                                            View {
                                                attr {
                                                    flex(btn.flex ?: 1f)
                                                    height(44f)
                                                    justifyContentCenter()
                                                    alignItemsCenter()
                                                    borderRadius(12f)
                                                    backgroundColor(
                                                        when (btn.style) {
                                                            CommonDialogButtonModel.ButtonStyle.PRIMARY -> Color(
                                                                0xFF2B76F0
                                                            )

                                                            CommonDialogButtonModel.ButtonStyle.SECONDARY -> Color(
                                                                0xFFE6E7EB
                                                            )
                                                        }
                                                    )
                                                }
                                                View {
                                                    attr {
                                                        size(14f, 14f)
                                                        if (ctx.primaryLoadingAnimating) {
                                                            transform(rotate = Rotate(360f))
                                                        } else {
                                                            transform(rotate = Rotate(0f))
                                                        }
                                                        animation(
                                                            Animation.linear(1.42f).repeatForever(true),
                                                            ctx.primaryLoadingAnimating
                                                        )
                                                    }
                                                   event {
                                                       didAppear {
                                                           setTimeout(50) {
                                                               ctx.primaryLoadingAnimating = true
                                                           }
                                                       }
                                                   }
                                                    Canvas({
                                                        attr {
                                                            size(14f, 14f)
                                                        }
                                                    }) { context, width, height ->
                                                        val strokeWidth = 2.5f
                                                        val radius = min(width, height) / 2f - strokeWidth / 2f
                                                        val centerX = width / 2f
                                                        val centerY = height / 2f
                                                        val startAngle = -90f
                                                        val sweepAngle = 288f
                                                        val steps = 36

                                                        context.beginPath()
                                                        context.lineCapRound()
                                                        context.strokeStyle(Color(0xFFFCFCFC))
                                                        context.lineWidth(strokeWidth)

                                                        for (i in 0..steps) {
                                                            val angle = (startAngle + sweepAngle * i / steps) * (PI / 180.0)
                                                            val x = centerX + (radius * cos(angle)).toFloat()
                                                            val y = centerY + (radius * sin(angle)).toFloat()
                                                            if (i == 0) {
                                                                context.moveTo(x, y)
                                                            } else {
                                                                context.lineTo(x, y)
                                                            }
                                                        }
                                                        context.stroke()
                                                    }
                                                }
                                            }
                                        } else {
                                            Button {
                                                attr {
                                                    height(44f)
                                                    justifyContentCenter()
                                                    alignItemsCenter()
                                                    borderRadius(12f)
                                                    flex(btn.flex ?: 1f)

                                                    // Style logic
                                                    backgroundColor(
                                                        when (btn.style) {
                                                            CommonDialogButtonModel.ButtonStyle.PRIMARY -> Color(
                                                                0xFF2B76F0
                                                            )

                                                            CommonDialogButtonModel.ButtonStyle.SECONDARY -> Color(
                                                                0xFFE6E7EB
                                                            )
                                                        }
                                                    )
//                                                highlightBackgroundColor(when (btn.style) {
//                                                    CommonDialogButtonModel.ButtonStyle.PRIMARY -> Color(0x332B76F0)
//                                                    CommonDialogButtonModel.ButtonStyle.SECONDARY -> Color(0x33E6E7EB)
//                                                })
                                                    titleAttr {
                                                        text(btn.title)
                                                        fontSize(18f)
                                                        fontWeightMedium()
                                                        color(
                                                            when (btn.style) {
                                                                CommonDialogButtonModel.ButtonStyle.PRIMARY -> Color(
                                                                    0xFFFCFCFC
                                                                )

                                                                CommonDialogButtonModel.ButtonStyle.SECONDARY -> Color(
                                                                    0xFF000000
                                                                )
                                                            }
                                                        )
                                                    }


                                                }
                                                event {
                                                    click {
                                                        if (!ctx.showPrimaryLoading) {
                                                            btn.onClick?.invoke()
                                                                ?: ctx.event.onButtonClick?.invoke(
                                                                    index
                                                                )
                                                            if (ctx.attr.needPrimaryLoading && btn.style == CommonDialogButtonModel.ButtonStyle.PRIMARY) {
                                                                ctx.showPrimaryLoading = true
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
