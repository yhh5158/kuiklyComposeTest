package com.example.dialogdemo

class CommonDialogButtonModel {
    enum class ButtonStyle {
        PRIMARY,
        SECONDARY
    }
    internal var title: String = ""
    // internal var loading: Boolean = false
    internal var icon: String = ""
    internal var style: CommonDialogButtonModel.ButtonStyle = CommonDialogButtonModel.ButtonStyle.PRIMARY
    internal var flex: Float? = null

    internal var onClick: (() -> Unit)? = null

    fun title(title: String) {
        this.title = title
    }

    // fun loading(loading: Boolean) {
    //     this.loading = loading
    // }

    fun icon(icon: String) {
        this.icon = icon
    }

    fun style(style: CommonDialogButtonModel.ButtonStyle) {
        this.style = style
    }

    fun flex(flex: Float) {
        this.flex = flex
    }

    fun onClick(onClick: (() -> Unit)) {
        this.onClick = onClick
    }
}