package com.example.dialogdemo

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.tencent.kuikly.compose.ComposeContainer
import com.tencent.kuikly.compose.foundation.layout.Box
import com.tencent.kuikly.compose.foundation.layout.Column
import com.tencent.kuikly.compose.foundation.layout.Spacer
import com.tencent.kuikly.compose.foundation.layout.fillMaxSize
import com.tencent.kuikly.compose.foundation.layout.height
import com.tencent.kuikly.compose.foundation.layout.padding
import com.tencent.kuikly.compose.material3.Button
import com.tencent.kuikly.compose.material3.Text
import com.tencent.kuikly.compose.setContent
import com.tencent.kuikly.compose.ui.Modifier
import com.tencent.kuikly.compose.ui.unit.dp
import com.tencent.kuikly.core.annotations.Page

/**
 * 弹窗测试页面 (Compose 版)
 */
@Page("DialogTestPageCompose")
class DialogTestPageCompose : ComposeContainer() {
    override fun willInit() {
        super.willInit()
        setContent {
            DialogTestScreen()
        }
    }
}

@Composable
fun DialogTestScreen() {
    var showDialog by remember { mutableStateOf(false) }
    var dialogTitle by remember { mutableStateOf("默认标题") }
    var dialogDesc by remember { mutableStateOf("默认描述") }
    var layoutType by remember { mutableStateOf(CommonDialogAttr.LayoutType.BOTTOM_SHEET) }
    var contentType by remember { mutableStateOf(CommonDialogAttr.ContentType.TEXT) }
    var kvList by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var showSelectDialog by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text("Compose CommonDialog 测试")
            Spacer(Modifier.height(20.dp))

//             按钮 1: 底部弹窗
            Button(onClick = {
                layoutType = CommonDialogAttr.LayoutType.BOTTOM_SHEET
                contentType = CommonDialogAttr.ContentType.TEXT
                dialogTitle = "底部弹窗"
                dialogDesc = "这是一个底部弹窗示例"
                showDialog = true
            }) {
                Text("显示底部弹窗")
            }

            Spacer(Modifier.height(10.dp))

            // 按钮 2: 居中弹窗
            Button(onClick = {
                layoutType = CommonDialogAttr.LayoutType.CENTER_MODAL
                contentType = CommonDialogAttr.ContentType.TEXT
                dialogTitle = "居中弹窗"
                dialogDesc = "这是一个居中确认弹窗"
                showDialog = true
            }) {
                Text("显示居中弹窗")
            }

            Spacer(Modifier.height(10.dp))

            // 按钮 3: KV 列表弹窗
            Button(onClick = {
                layoutType = CommonDialogAttr.LayoutType.BOTTOM_SHEET
                contentType = CommonDialogAttr.ContentType.KV_LIST
                dialogTitle = "用户信息"
                dialogDesc = ""
                kvList = listOf(
                    "姓名" to "张三",
                    "年龄" to "25",
                    "职业" to "Android 开发"
                )
                showDialog = true
            }) {
                Text("显示 KV 弹窗")
            }

            Spacer(Modifier.height(10.dp))

            // 按钮 4: 动态改变内容
            Button(onClick = {
                if (showDialog) {
                    dialogDesc = "描述已被动态改变: www"
                }
            }) {
                Text("动态更新当前弹窗内容 (测试 Observable)")
            }

            Spacer(Modifier.height(20.dp))
            Button(onClick = { showSelectDialog = true }) {
                Text("显示 Select 弹窗 (参考对照)")
            }

        }

        // 弹窗组件 (Persistent)
        CommonDialogCompose(
            modifier = Modifier.fillMaxSize(),
            showDialog = showDialog,
            layoutType = layoutType,
            title = dialogTitle,
            description = dialogDesc,
            contentType = contentType,
            contentKvList = kvList,
            buttons = listOf(
                CommonDialogButtonModel().apply {
                    title = "取消"
                    style = CommonDialogButtonModel.ButtonStyle.SECONDARY
                    onClick = { showDialog = false }
                },
                CommonDialogButtonModel().apply {
                    title = "确定"
                    style = CommonDialogButtonModel.ButtonStyle.PRIMARY
                    onClick = { showDialog = false }
                }
            ),
            onCancel = { showDialog = false }
        )

    }
}
