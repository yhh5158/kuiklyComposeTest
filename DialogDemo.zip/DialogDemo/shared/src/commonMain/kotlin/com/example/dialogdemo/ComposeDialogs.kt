package com.example.dialogdemo

import androidx.compose.runtime.Composable
import com.tencent.kuikly.compose.extension.MakeKuiklyComposeNode
import com.tencent.kuikly.compose.ui.Modifier

/**
 * 通用弹窗 Compose 封装
 */
@Composable
fun CommonDialogCompose(
    showDialog: Boolean,
    layoutType: CommonDialogAttr.LayoutType = CommonDialogAttr.LayoutType.BOTTOM_SHEET,
    title: String = "",
    description: String = "",
    icon: String = "",
    contentType: CommonDialogAttr.ContentType = CommonDialogAttr.ContentType.TEXT,
    contentText: String = "",
    contentKvList: List<Pair<String, String>> = emptyList(),
    buttons: List<CommonDialogButtonModel> = emptyList(),
    modifier: Modifier = Modifier,
    onCancel: (() -> Unit)? = null,
    onButtonClick: ((Int) -> Unit)? = null
) {
    // 提取更新逻辑
    val updateBlock: (CommonDialog) -> Unit = { view ->
        view.getViewAttr().run {
            showDialog(showDialog)
            layoutType(layoutType)
            title(title)
            description(description)
            icon(icon)
            buttons(ArrayList(buttons))
            
            when (contentType) {
                CommonDialogAttr.ContentType.TEXT -> content(contentText)
                CommonDialogAttr.ContentType.KV_LIST -> content(ArrayList(contentKvList))
                else -> {}
            }
        }
        view.getViewEvent().run {
            this.onCancel = onCancel
            this.onButtonClick = onButtonClick
        }
    }


    MakeKuiklyComposeNode<CommonDialog>(
        factory = { CommonDialog() },
        modifier = modifier,
        viewInit = {
            updateBlock(this)
        },
        viewUpdate = updateBlock
    )
}


